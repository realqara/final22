import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Home from './pages/Home';
import Admin from './pages/Admin';
import Editor from './pages/Editor';

const App = () => {
  return (
    <Router>
      <div>
        <h1>Welcome to Portfolio Platform</h1>
        <Switch>
          <Route path="/register" component={Register} />
          <Route path="/login" component={Login} />
          <Route path="/home" component={Home} />
          <Route path="/admin" component={Admin} />
          <Route path="/editor" component={Editor} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;