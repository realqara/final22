import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    twoFactorCode: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:3000/api/auth/login', formData)
      .then((response) => {
        alert('Login successful');
      })
      .catch((error) => {
        alert('Login failed');
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="username"
        onChange={handleChange}
        placeholder="Username"
        required
      />
      <input
        type="password"
        name="password"
        onChange={handleChange}
        placeholder="Password"
        required
      />
      <input
        type="text"
        name="twoFactorCode"
        onChange={handleChange}
        placeholder="2FA Code"
        required
      />
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;