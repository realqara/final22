const ensureAdmin = (req, res, next) => {
    if (req.user.role === 'admin') {
       return next();
    }
    res.status(403).send('Access denied');
 };
 
 const ensureEditor = (req, res, next) => {
    if (req.user.role === 'editor' || req.user.role === 'admin') {
       return next();
    }
    res.status(403).send('Access denied');
 };
 
 module.exports = { ensureAdmin, ensureEditor };