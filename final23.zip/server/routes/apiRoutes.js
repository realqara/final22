const express = require('express');
const axios = require('axios');
const router = express.Router();

const weatherApiKey = process.env.WEATHER_API_KEY;  


router.get('/air-quality', async (req, res) => {
    const { lat, lon } = req.query;  
    if (!lat || !lon) {
        return res.status(400).json({ error: 'Latitude and longitude are required' });
    }

    const airQualityUrl = http//api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${weatherApiKey};

    try {
        const response = await axios.get(airQualityUrl);
        const data = response.data;

        
        res.json({
            aqi: data.list[0].main.aqi,
            pollutants: data.list[0].components
        });
    } catch (error) {
        console.error('Error fetching air quality data:', error);
        res.status(500).json({ error: 'Failed to fetch air quality data', details: error.message });
    }
});

module.exports = router;