const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const { ensureAdmin, ensureEditor } = require('../middleware/role');
const portfolioController = require('../controllers/portfolioController');

// Admin & Editor can create portfolio
router.post('/create', authenticateToken, ensureEditor, portfolioController.createPortfolio);

// Admin only can update and delete
router.put('/update/:id', authenticateToken, ensureAdmin, portfolioController.updatePortfolio);
router.delete('/delete/:id', authenticateToken, ensureAdmin, portfolioController.deletePortfolio);

module.exports = router;