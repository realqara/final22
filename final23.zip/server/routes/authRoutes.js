const express = require('express');
const bcrypt = require('bcryptjs');
const speakeasy = require('speakeasy');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const User = require('../models/User');
const router = express.Router();

// Nodemailer setup for email sending
const transporter = nodemailer.createTransport({
   service: 'postmark', // Update this for Postmark or your email service
   auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
   }
});

// Registration route
router.post('/register', async (req, res) => {
   const { username, password, firstName, lastName, age, gender, email } = req.body;

   if (!username || !password || !firstName || !lastName || !age || !gender || !email) {
      return res.status(400).send('All fields are required');
   }

   try {
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Generate 2FA secret
      const twoFactorSecret = speakeasy.generateSecret({ name: 'UserApp' });

      const newUser = new User({
         username,
         password: hashedPassword,
         firstName,
         lastName,
         age,
         gender,
         email,
         twoFactorSecret: twoFactorSecret.base32
      });

      await newUser.save();

      // Send welcome email
      const mailOptions = {
         from: process.env.EMAIL_USER,
         to: email,
         subject: 'Welcome to Our App!',
         text: `Hi ${firstName}, welcome to our app. Your 2FA secret is: ${twoFactorSecret.base32}`
      };

      transporter.sendMail(mailOptions, (error, info) => {
         if (error) {
            console.error('Error sending email:', error);
            return res.status(500).send('Error sending email');
         }
         res.status(201).send('User registered successfully');
      });

   } catch (error) {
      console.error('Error registering user:', error);
      res.status(500).send('Error registering user');
   }
});

// Login route
router.post('/login', async (req, res) => {
   const { username, password, twoFactorCode } = req.body;

   if (!username || !password) {
      return res.status(400).send('Username and password are required');
   }

   try {
      const user = await User.findOne({ username });
      if (!user) {
         return res.status(400).send('Invalid username or password');
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
         return res.status(400).send('Invalid username or password');
      }

      // Verify 2FA if enabled
      if (user.twoFactorSecret) {
         const verified = speakeasy.totp.verify({
            secret: user.twoFactorSecret,
            encoding: 'base32',
            token: twoFactorCode
         });

         if (!verified) {
            return res.status(400).send('Invalid 2FA code');
         }
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user._id, username: user.username, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

      res.status(200).send({ message: 'Login successful', token });

   } catch (error) {
      console.error('Error during login:', error);
      res.status(500).send('Error during login');
   }
});

module.exports = router;

