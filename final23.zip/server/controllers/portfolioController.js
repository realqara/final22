const Portfolio = require('../models/Portfolio');

module.exports.createPortfolio = async (req, res) => {
   const { title, description, images } = req.body;

   const portfolio = new Portfolio({
      title,
      description,
      images,
      createdBy: req.user.id,  // Assign to logged-in user
   });

   try {
      await portfolio.save();
      res.json({ message: 'Portfolio item created successfully' });
   } catch (err) {
      console.error(err);
      res.status(500).send('Error creating portfolio item');
   }
};

module.exports.updatePortfolio = async (req, res) => {
   const { title, description, images } = req.body;

   try {
      const portfolio = await Portfolio.findById(req.params.id);
      if (!portfolio || portfolio.createdBy.toString() !== req.user.id) {
         return res.status(403).send('Forbidden');
      }

      portfolio.title = title || portfolio.title;
      portfolio.description = description || portfolio.description;
      portfolio.images = images || portfolio.images;
      portfolio.updatedAt = Date.now();

      await portfolio.save();
      res.json({ message: 'Portfolio item updated successfully' });
   } catch (err) {
      console.error(err);
      res.status(500).send('Error updating portfolio item');
   }
};

module.exports.deletePortfolio = async (req, res) => {
   try {
      const portfolio = await Portfolio.findById(req.params.id);
      if (!portfolio || portfolio.createdBy.toString() !== req.user.id) {
         return res.status(403).send('Forbidden');
      }

      await portfolio.remove();
      res.json({ message: 'Portfolio item deleted successfully' });
   } catch (err) {
      console.error(err);
      res.status(500).send('Error deleting portfolio item');
   }
};