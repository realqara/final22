const mongoose = require('mongoose');

const portfolioSchema = new mongoose.Schema({
   title: { type: String, required: true },
   description: { type: String, required: true },
   images: [{ type: String }],  // Array of image URLs
   createdAt: { type: Date, default: Date.now },
   updatedAt: { type: Date },
   createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Reference to the user who created it
});

const Portfolio = mongoose.model('Portfolio', portfolioSchema);

module.exports = Portfolio;